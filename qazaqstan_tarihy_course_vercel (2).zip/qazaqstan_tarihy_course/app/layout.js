import "./globals.css";

export const metadata = {
  title: "Қазақстан тарихы — онлайн курс",
  description: "Қазақстан тарихын кезең-кезеңімен меңгеруге арналған оқу курсы"
};

export default function RootLayout({ children }) {
  return (
    <html lang="kk">
      <body>{children}</body>
    </html>
  );
}
