 "use client";

import { useMemo, useState } from "react";

const modules = [
  {
    title: "1-модуль. Ежелгі Қазақстан",
    icon: "🏺",
    lessons: [
      { title: "Алғашқы адамдар және тас дәуірі", text: "Қазақстан аумағындағы алғашқы адамдардың тіршілігі, тас құралдары және алғашқы қауымдық құрылыс туралы негізгі ұғымдар.", quiz: [["Қазақстандағы тас дәуірінің негізгі кезеңдерінің бірі?", ["Палеолит","Қайта өрлеу","Орта ғасыр","Жаңа заман"],0]] },
      { title: "Сақтар", text: "Сақ тайпалары, олардың шаруашылығы, қоғамдық құрылысы және мәдениеті. Томирис пен Шырақ туралы тарихи деректер.", quiz: [["Сақтардың әйгілі патшайымы?", ["Томирис","Бопай","Айша","Домалақ ана"],0]] },
      { title: "Үйсіндер мен Қаңлылар", text: "Үйсіндер мен Қаңлы мемлекеттерінің орналасуы, шаруашылығы және көрші елдермен байланысы.", quiz: [["Үйсіндердің астанасы ретінде деректерде қай қала аталады?", ["Чигу","Отырар","Сығанақ","Сарайшық"],0]] }
    ]
  },
  {
    title: "2-модуль. Түркі дәуірі",
    icon: "🐎",
    lessons: [
      { title: "Түрік қағанаты", text: "552 жылы құрылған Түрік қағанатының саяси тарихы, аумағы және түркі халықтарының қалыптасуындағы орны.", quiz: [["Түрік қағанаты қай жылы құрылды?", ["552","603","751","840"],0]] },
      { title: "Қарахан мемлекеті", text: "Қарахан мемлекетінің құрылуы, исламның таралуы, қалалық мәдениет және сәулет өнері.", quiz: [["Қарахан мемлекетінде ислам дінінің орнығуына ықпал еткен билеуші?", ["Сатұқ Боғра хан","Абылай хан","Керей хан","Есім хан"],0]] },
      { title: "Қыпшақтар", text: "Қыпшақ хандығы, Дешті Қыпшақ даласы және қыпшақтардың Еуразия тарихындағы орны.", quiz: [["Қыпшақтар мекендеген кең дала қалай аталды?", ["Дешті Қыпшақ","Жетісу","Мауараннахр","Моғолстан"],0]] }
    ]
  },
  {
    title: "3-модуль. Қазақ хандығы",
    icon: "🏰",
    lessons: [
      { title: "Қазақ хандығының құрылуы", text: "Керей мен Жәнібек сұлтандардың бөлінуі, Қазақ хандығының құрылуы және оның тарихи маңызы.", quiz: [["Қазақ хандығының негізін қалаған хандар?", ["Керей мен Жәнібек","Қасым мен Хақназар","Тәуке мен Абылай","Есім мен Жәңгір"],0]] },
      { title: "Қасым хан", text: "Қасым хан тұсындағы Қазақ хандығының күшеюі және «Қасым ханның қасқа жолы» заңдар жүйесі.", quiz: [["Қасым ханның заңдар жүйесі қалай аталды?", ["Қасым ханның қасқа жолы","Жеті жарғы","Есім ханның ескі жолы","Төре ережесі"],0]] },
      { title: "Тәуке хан және Жеті жарғы", text: "Тәуке хан дәуірі, билер кеңесі және қазақ қоғамындағы құқықтық нормаларды жүйелеу.", quiz: [["«Жеті жарғы» қай ханның тұсында жүйеленді?", ["Тәуке хан","Қасым хан","Абылай хан","Керей хан"],0]] }
    ]
  },
  {
    title: "4-модуль. XVIII–XIX ғасырлар",
    icon: "⚔️",
    lessons: [
      { title: "Жоңғар шапқыншылығы", text: "Қазақ-жоңғар қатынастары, «Ақтабан шұбырынды» кезеңі және халықтың азаттық күресі.", quiz: [["«Ақтабан шұбырынды» қай кезеңмен байланысты?", ["Жоңғар шапқыншылығы","Ұлы Жібек жолы","Алаш қозғалысы","Тың игеру"],0]] },
      { title: "Абылай хан", text: "Абылай ханның саясаты, үш жүздің басын біріктірудегі рөлі және сыртқы байланыстары.", quiz: [["Абылай ханның негізгі саяси мақсатының бірі?", ["Қазақ жерінің тұтастығын сақтау","Теңіз флотын құру","Жаңа астана салу","Еуропаға көшу"],0]] },
      { title: "Ұлт-азаттық көтерілістер", text: "XIX ғасырдағы отаршылдыққа қарсы қозғалыстар және олардың себептері мен тарихи маңызы.", quiz: [["Кенесары Қасымұлы бастаған көтеріліс қай ғасырда болды?", ["XIX ғасырда","XV ғасырда","XVII ғасырда","XX ғасырда"],0]] }
    ]
  },
  {
    title: "5-модуль. XX ғасыр",
    icon: "📜",
    lessons: [
      { title: "Алаш қозғалысы", text: "Алаш қозғалысының қалыптасуы, Алаш партиясы, ұлттық автономия идеясы және Алаш зиялылары.", quiz: [["Алаш қозғалысының көрнекті қайраткерлерінің бірі?", ["Әлихан Бөкейхан","Қорқыт","Қасым хан","Абылай хан"],0]] },
      { title: "1916 жылғы көтеріліс", text: "1916 жылғы ұлт-азаттық көтерілістің себептері, негізгі ошақтары және тарихи маңызы.", quiz: [["1916 жылғы көтеріліске түрткі болған патша жарлығы қай мәселені қамтыды?", ["Тыл жұмыстарына адам алу","Жер реформасы","Салықты жою","Әскерді тарату"],0]] },
      { title: "Желтоқсан оқиғасы", text: "1986 жылғы Алматыдағы Желтоқсан оқиғасының себептері, барысы және тарихи маңызы.", quiz: [["Желтоқсан оқиғасы қай жылы болды?", ["1986","1979","1991","1995"],0]] }
    ]
  },
  {
    title: "6-модуль. Тәуелсіз Қазақстан",
    icon: "🇰🇿",
    lessons: [
      { title: "Қазақстанның тәуелсіздігі", text: "1991 жылғы 16 желтоқсанда Қазақстанның мемлекеттік тәуелсіздігі туралы заңның қабылдануы.", quiz: [["Қазақстан тәуелсіздігін қашан жариялады?", ["16 желтоқсан 1991","25 қазан 1990","30 тамыз 1995","1 желтоқсан 1991"],0]] },
      { title: "Мемлекеттік рәміздер", text: "Қазақстан Республикасының Туы, Елтаңбасы және Әнұраны — мемлекеттің негізгі рәміздері.", quiz: [["Қазақстанның мемлекеттік рәміздеріне не жатады?", ["Ту, Елтаңба, Әнұран","Ту, Конституция, Елтаңба","Әнұран, теңге, паспорт","Елтаңба, Астана, Ту"],0]] },
      { title: "Конституция", text: "Қазақстан Республикасының Конституциясы, азаматтардың құқықтары мен міндеттері және мемлекеттік құрылым негіздері.", quiz: [["Қазақстан Республикасының Конституциясы қай жылы бүкілхалықтық референдумда қабылданды?", ["1995","1991","1993","1997"],0]] }
    ]
  }
];

export default function Home() {
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState("");
  const [done, setDone] = useState([]);
  const [quizAnswer, setQuizAnswer] = useState(null);

  const lessons = useMemo(() => modules.flatMap((m, mi) => m.lessons.map((l, li) => ({...l, mi, li, module: m.title}))), []);
  const filtered = lessons.filter(l => `${l.title} ${l.module}`.toLowerCase().includes(search.toLowerCase()));

  function openLesson(lesson) {
    setSelected(lesson);
    setQuizAnswer(null);
    window.scrollTo({top: 0, behavior: "smooth"});
  }

  function markDone() {
    if (!selected) return;
    const key = `${selected.mi}-${selected.li}`;
    if (!done.includes(key)) setDone([...done, key]);
  }

  const progress = Math.round((done.length / lessons.length) * 100);

  return (
    <main>
      <header className="hero">
        <nav className="nav">
          <div className="brand"><span>🇰🇿</span> Tarih Academy</div>
          <div className="navlinks">
            <a href="#course">Курс</a>
            <a href="#about">Курс туралы</a>
          </div>
        </nav>
        <div className="heroContent">
          <div className="badge">ОНЛАЙН КУРС • ҚАЗАҚСТАН ТАРИХЫ</div>
          <h1>Өткенді біл —<br/><span>болашақты таны.</span></h1>
          <p>Қазақстан тарихын ежелгі дәуірден тәуелсіз Қазақстанға дейін кезең-кезеңімен меңгер.</p>
          <a className="primary" href="#course">Курсты бастау →</a>
        </div>
      </header>

      <section className="stats">
        <div><strong>{modules.length}</strong><span>Модуль</span></div>
        <div><strong>{lessons.length}</strong><span>Сабақ</span></div>
        <div><strong>{progress}%</strong><span>Прогресс</span></div>
        <div><strong>100%</strong><span>Онлайн</span></div>
      </section>

      <section id="course" className="course">
        <div className="sectionHead">
          <div>
            <div className="eyebrow">КУРС БАҒДАРЛАМАСЫ</div>
            <h2>Қазақстан тарихы</h2>
            <p>Өзіңе ыңғайлы қарқынмен оқып, әр сабақ соңындағы тест арқылы біліміңді тексер.</p>
          </div>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="🔎  Сабақ іздеу..." />
        </div>

        {selected && (
          <div className="lessonPanel">
            <button className="back" onClick={() => setSelected(null)}>← Барлық сабаққа</button>
            <div className="lessonMeta">{selected.module}</div>
            <h2>{selected.title}</h2>
            <p className="lessonText">{selected.text}</p>
            <div className="quiz">
              <h3>📝 Өзіңді тексер</h3>
              {selected.quiz.map((q, qi) => (
                <div key={qi}>
                  <p><b>{q[0]}</b></p>
                  <div className="answers">
                    {q[1].map((a, i) => (
                      <button key={a} className={quizAnswer !== null ? (i === q[2] ? "correct" : i === quizAnswer ? "wrong" : "") : ""} onClick={() => setQuizAnswer(i)}>{a}</button>
                    ))}
                  </div>
                  {quizAnswer !== null && <div className={quizAnswer === q[2] ? "feedback good" : "feedback bad"}>{quizAnswer === q[2] ? "Дұрыс жауап! 🎉" : `Дұрыс жауап: ${q[1][q[2]]}`}</div>}
                </div>
              ))}
            </div>
            <button className="primary done" onClick={markDone}>{done.includes(`${selected.mi}-${selected.li}`) ? "✓ Сабақ аяқталды" : "Сабақты аяқтау"}</button>
          </div>
        )}

        {!selected && (
          <>
            {search && <div className="searchCount">Табылған сабақ: {filtered.length}</div>}
            <div className="modules">
              {modules.map((m, mi) => (
                <div className="module" key={m.title}>
                  <div className="moduleTop">
                    <span className="moduleIcon">{m.icon}</span>
                    <div><div className="moduleNum">МОДУЛЬ {mi+1}</div><h3>{m.title.replace(/^\d+-модуль\. /, "")}</h3></div>
                  </div>
                  <div className="lessonList">
                    {(search ? filtered.filter(l => l.mi === mi) : m.lessons.map((l, li) => ({...l, mi, li, module: m.title}))).map(l => {
                      const key = `${l.mi}-${l.li}`;
                      return (
                        <button className="lessonRow" key={key} onClick={() => openLesson(l)}>
                          <span className="lessonNo">{l.li + 1}</span>
                          <span>{l.title}</span>
                          <span className="status">{done.includes(key) ? "✓" : "→"}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </section>

      <section id="about" className="about">
        <div>
          <div className="eyebrow">КУРС ТУРАЛЫ</div>
          <h2>Тарихты жүйелі түрде үйрен.</h2>
          <p>Бұл оқу платформасы Қазақстан тарихының негізгі кезеңдерін модульдерге бөліп, теория мен қысқа тесттерді бір жерге жинайды.</p>
        </div>
        <div className="aboutCard">
          <span>🎯</span><b>Мақсат</b><p>Тарихи оқиғаларды хронологиялық және себеп-салдарлық байланыста түсіну.</p>
        </div>
        <div className="aboutCard">
          <span>🧠</span><b>Әдіс</b><p>Қысқа теория + өзін-өзі тексеру + сабақ прогресі.</p>
        </div>
      </section>

      <footer>© 2026 Tarih Academy • Қазақстан тарихы онлайн курсы</footer>
    </main>
  );
}
